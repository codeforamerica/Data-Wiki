<?php
?>
<div<?php if ($class) { print ' class="'. $class .'"'; } ?>>
<h3><?php print $title ?></h3>
    <div>
    <?php print $content ?>
    </div>
</div>